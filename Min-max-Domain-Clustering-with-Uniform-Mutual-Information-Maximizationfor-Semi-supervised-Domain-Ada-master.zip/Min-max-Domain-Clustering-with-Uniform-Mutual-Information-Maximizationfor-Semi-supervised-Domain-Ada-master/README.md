# Approach Semi-supervised Domain Adaptation from Two Perspective

EECS 542 4-student Group Project (each team member contributed equally to this project).

Feel free to find details in our report https://drive.google.com/file/d/1rwxnIiOJPfmQAJP7JgYmMBWaVxQofvcG/view.

Feel free to watch our video for this project https://drive.google.com/file/d/1GvuzagFYtzl7pGPiATP2Bm3_BxO67hOX/view.




Overview figure:



<img src="Fig1.PNG" alt="Fig1" style="zoom: 25%;" />
=======


